# Diseñador de Riego V2

Proyecto Android listo para compilar y generar un APK.

## Funciones incluidas

### Plano
- Dibujo de parcelas irregulares mediante puntos.
- Cálculo automático de superficie y perímetro.
- Cuadrícula en metros.
- Colocación de emisores dentro de la parcela.
- Cuatro tipos de emisor:
  - Rotor 90°
  - Difusor 180°
  - Aspersor 360°
  - Banda 180°
- Radio y caudal asociados a cada tipo.
- Creación de sectores/zones.
- Dibujo de tramos de tubería.

### Cálculo
- Estimación de superficie cubierta mediante muestreo de la parcela.
- Porcentaje de cobertura.
- Caudal estimado por sector.
- Comparación con caudal disponible.
- Parámetro de presión de entrada.
- Recomendación preliminar de diámetro según caudal.

### Materiales
- Emisores.
- Electroválvulas.
- Programador.
- Metros de tubería.
- Conexiones.
- Cajas de válvulas.
- Tapón final.

## Compilación

1. Abrir esta carpeta con Android Studio.
2. Esperar a que termine Gradle Sync.
3. Build > Build APK(s).
4. APK: app/build/outputs/apk/debug/app-debug.apk

## Importante

El cálculo hidráulico de esta V2 es preliminar y sirve para diseñar un primer esquema. Antes de ejecutar una instalación real hay que verificar pérdidas de carga, presión mínima de cada emisor, desniveles, longitudes, diámetro real, caudal disponible, sectorización, válvulas y normativa aplicable.

## Próximas mejoras recomendadas

- Guardar proyectos.
- Deshacer/rehacer puntos.
- Editar y mover vértices.
- Importar ortofoto/plano de la parcela.
- Escala desde una distancia conocida.
- Orientación y sectores de los aspersores.
- Solape real por sectores y ángulos.
- Cálculo hidráulico por Hazen-Williams/Darcy-Weisbach.
- Desnivel y cotas.
- Exportación PDF.
- Presupuesto con precios configurables.
- Compartir proyecto.
